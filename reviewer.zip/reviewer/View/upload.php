<?php
    require_once '../Control/operations.php';
    $db = new operation();
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if(isset($_POST['image64']) and isset($_POST['imageName']) and isset($_POST['question_no']) and isset($_POST['id']) and isset($_POST['subject_id']) and isset( $_POST['studentID'])){
            // TODO: update android code
            $name = $_POST['imageName'];
            $uploadPath = "../../paper_review/portal/paper_pics/".$name.".jpg";
            $question_no = $_POST['question_no'];
            $response = array();
            if (file_put_contents($uploadPath,base64_decode($_POST['image64']))){
                
                if($db->uploadPics($question_no,$uploadPath) == true){

                    $response['error'] = false;
                    $response['response'] = "Image uploaded Sucessfully";
                }else{
                    $response['error'] = true;
                    $response['response'] = "Someting went wrong1";
                }
                
            }else{
                $response['error'] = true;
                $response['response'] = "Someting went wrong2";
            }
        }else{
            $response['error'] = true;
            $response['response'] = "Missing parametter";
        }
    }else{
        $response['error'] = true;
        $response['response'] = "Invalid request";
    }
    echo json_encode($response);

    if($response['error'] == false){
        $db->distribute($_POST['id'] , $_POST['subject_id'] , $_POST['studentID'],$uploadPath ,$question_no );
    }
?>