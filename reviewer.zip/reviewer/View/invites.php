<?php
    require_once '../Control/operations.php';
    $response = array();
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        if(isset($_POST['number']) ){
            $db = new operation();
            $i = 0;
            while($i < $_POST['number']){
                // echo $_POST['number'];
                $db->insertNumber($_POST[$i]);
                $i+=1;
            }
            $response['error'] = false;
            $response['response'] = "Data uploaded";
        }else{
            $response['error'] = true;
            $response['response'] = "Required parameter are missing";
        }
    }else{
        
        $response['error'] = true;
        $response['response'] = 'Invalid request';
    }
    echo json_encode($response);

?>

