<?php
    require_once '../Control/operations.php';
    $response = array();
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        if(isset($_POST['email']) and isset($_POST['password'])){
            $db = new operation();
            $result =  $db->getUserInfo($_POST['email'],$_POST['password']);
            if (is_int($result)){
                $response['error'] = true;
                $response['response'] = 'Invalid Username or Password';
            }else{
                $response['error'] = false;
                $response['id'] = $result['id'];
                $response['name'] = $result['name'];
                $response['semester'] = $result['semester'];
                $response['response'] = "Signed in sucessfully";
            }
        }else{
            $response['error'] = true;
            $response['response'] = "Required parameter are missing";
        }
    }else{
        
        $response['error'] = true;
        $response['response'] = 'Invalid request';
    }
    echo json_encode($response);
    

?>