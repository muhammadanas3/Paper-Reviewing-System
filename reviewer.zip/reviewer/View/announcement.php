<?php
    require_once '../Control/operations.php';
    $response = array();
	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		if(isset($_POST['semester']))
		{
			$db = new operation();
			$result = $db->getAnnoncement($_POST['semester']);
			// if($result->num_rows > 0){
			//     $result = $result->fetch_assoc();
			//     // $response['error'] = false;
			//     $response['teacher_id'] = $result['teacher_id'];
			//     $response['subject_id'] = $result['subject_id'];
			//     $response['exam'] = $result['exam'];
			// }
			if($result->num_rows > 0){
				$response['data'] = true;
				$data = array();
					while($values = $result->fetch_assoc()){
						$temp = array();
						$temp['id'] = $values['id'] ;
						$temp['teacher_id'] = $values['teacher_id'] ;
						$temp['subject_id'] = $values['subject_id'] ;
						$result1 = $db->getSubject($temp['subject_id']);
						$temp['subject'] = $result1->name;
						$temp['exam'] = $values['exam'] ;
						$temp['q_nos'] = $values['q_nos'] ;
						array_push($data,$temp);
					}
					$response['response'] = $data;
			}else{
				$response['data'] = false;
				$response['error'] = "No announcement avialable";
			}
		}else{
			$response['data'] = false;
			$response['error'] = "Missing parameter";
		}
	}
    
    echo json_encode($response);
    
?>