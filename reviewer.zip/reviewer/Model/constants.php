<?php
    define("DB_NAME","paper_review_new");
    define("DB_USER","root");
    define("DB_PASSWORD","");
    define("DB_HOST","localhost");

?>