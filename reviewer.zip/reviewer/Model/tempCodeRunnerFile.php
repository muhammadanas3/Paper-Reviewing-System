<?php
if(mysqli_connent_errno()){