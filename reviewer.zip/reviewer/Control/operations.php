<?php
    
    class operation{
        private $con;

        function __construct(){
            include_once '../Model/connect.php';
            $DB = new DBConnect();
            $this->con = $DB->connect();
        }


        public function getUserInfo($email , $password){
            // $querey = $this->con->prepare("select * from student");
            // $querey->execute();
            // $data = $querey->get_result()->fetch_assoc();
            // echo "\n".$data["name"];
            // $queri = "select * from student where email = '$email'";
            // $result =  $this->con->query($queri);
            // if($result){
            //     echo $this->con->error;
            
            // }
            // echo $this"\n";
            // if (  !$this->checkEmail($email) ){
            //     return    -1 ; //"Invalid  Email";
            // }
            // else
            // {
                // $result =  $this->con->query("select * from student where email = '".$email."' and password = '".$password."'");
            $result = $this->checkPassword($password, $email);
            if($result->num_rows > 0){
                return $result->fetch_assoc();
            }else{
                return 0 ;
            }
                
            // }
        }
        // public function checkEmail($email){
        //     $queri = "select * from student where email = '$email'";
        //     $result =  $this->con->query($queri);
        //     return $result->num_rows > 0;

        // }
        public function checkPassword($password,$email){
            $result =  $this->con->query("select * from student where email = '".$email."' and password = '".$password."'");
            return $result;
        }
        public function getAnnoncement($semester){
            $result =  $this->con->query("select * from announcement where subject_id in (select id from subject where semester = ".$semester." )");
            if($result){
                echo $this->con->error;
            
            }
            return $result;
        }

        public function uploadPics($question_no,$uploadPath)
        {
            $insertData = "Insert into pics (path , question_no ) values ('".$uploadPath."' , ".$question_no."  )";
            return $this->con->query($insertData) == true;
        }

        public function distribute($id , $subject_id , $studentID, $uploadPath ,$question_no ){
            $myQuery1 = "select distinct teacher_tag from teacher_tag t where t.tag_id in( SELECT tag_id FROM `subject_tag` WHERE `subject_id` = ".$subject_id.") AND 10 > (select tot_review_papers from teacher where id = t.teacher_tag ) limit 2";
            $result = $this->con->query($myQuery1);
            
            if($result->num_rows > 0){
                while($values = $result->fetch_assoc()){
                    
                    $insertQuery = "insert into reviewer (announcement_id , reviewer_id ,  student_id , type, pic_path, q_no) values ( '$id'
                     , '{$values['teacher_tag']}' , '$studentID' , 't', '$uploadPath', '$question_no')";
                    // echo $insertQuery;
                    $this->con->query($insertQuery);

                    $updateQuery = "update teacher t set tot_review_papers =  (t.tot_review_papers + 1) where t.id = '{$values['teacher_tag']}'";
                    $this->con->query($updateQuery);
                    // echo $this->con->error;
                }  
            }

            $myQuery1 = "select distinct student_id from student_tag t where t.tag_id in ( SELECT tag_id FROM `subject_tag` WHERE `subject_id` = ".$subject_id.") AND 10 > (select tot_review_papers from student where id = t.student_id and id != '$studentID' ) limit 2";
            echo $myQuery1;
            $result = $this->con->query($myQuery1);
            echo $this->con->error;
            if($result->num_rows > 0){
                while($values = $result->fetch_assoc()){
//                    
//                    $insertQuery = "insert into reviewer (announcement_id , reviewer_id ,  student_id , type) values ( '$id'
//                     , '{$values['student_id']}' , '$studentID' , 's' )";
                    $insertQuery = "insert into reviewer (announcement_id , reviewer_id ,  student_id , type, pic_path, q_no) values ( '$id'
                     , '{$values['student_id']}' , '$studentID' , 's', '$uploadPath', '$question_no')";
                    echo $insertQuery;
                    $this->con->query($insertQuery);

                    $updateQuery = "update student t set tot_review_papers =  (t.tot_review_papers + 1) where t.id = '{$values['student_id']}'";
                    $this->con->query($updateQuery);
                    // echo $this->con->error;
                }  
            }

            
            
         }
         public function insertNumber($number){
             $querey = "Insert into invite (number) values ($number)";
             $this->con->query($querey );
            //  echo $this->con->error;

         }
         public function getSubject($subject_id){
            $querey = "Select name from subject where id = '$subject_id'";
            $result = $this->con->query($querey);
             echo $this->con->error;
            // echo $querey;
            // $result = $result->get_result();
            return $result->fetch_object();
            // return $result->fetch_array();
         }
        
    }

    
    // $a = new operation();

    // $x = $a->getUserInfo("hdfe","1234");
    // echo $x["name"];

?>