<?php
f($result){
                echo $this->con->error;
            
            }