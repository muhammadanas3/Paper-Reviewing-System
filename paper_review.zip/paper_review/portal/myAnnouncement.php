
<h1 class="page-header">
  My Announcements
</h1>

<div class="col-md-4">
    
   <?php
        get_announcements();    
    ?>

</div>

</div>

