
<h1 class="page-header">
  Comments
</h1>

        <?php
          get_std_comments();    
        ?>
        <br>
    
        <form method="post">
            <input class="form-control" type="text" name="comnt" placeholder="Add a comment" required>
            <br>
            <button class="btn btn-primary" name="add">Add</button>
        </form>

        <?php
            if(isset($_POST['add']))
            {
                addSComment($_POST['comnt'], $_GET['std_comments']);
                redirect("std_portal.php?std_comments={$_GET['std_comments']}&std_id={$_GET['std_id']}");
            }
        ?>

    </div>



</div>

