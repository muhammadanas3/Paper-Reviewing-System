
<h1 class="page-header">
  Comments
</h1>

        <?php
          get_comments();    
        ?>
        <br>
    
        <form method="post">
            <input class="form-control" type="text" name="comnt" placeholder="Add a comment" required>
            <br>
            <button class="btn btn-primary" name="add">Add</button>
        </form>

        <?php
            if(isset($_POST['add']))
            {
                addRComment($_POST['comnt'], $_GET['ann']);
                redirect("tchr_portal.php?comment={$_GET['comment']}&ann={$_GET['ann']}");
                
            }
        ?>

    </div>



</div>

