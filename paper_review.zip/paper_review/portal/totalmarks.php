
<h1 class="page-header">
  Enter total marks for
</h1>

<div class="col-md-4">
    
    <form method="post">
    
        <div class="form-group">
            
            
            <?php
                $i = (int)$_GET['totalmarks'];
                $n = 1;
                while($i > 0)
                {
                    echo"
                        <h3>Q{$n}</h3> <input type='text' name = 'q{$n}' required>
                        <br>
                    ";
                    $i--;
                    $n++;
                }
            
            ?>
            
            
            
        </div>

        <div class="form-group">
            <button class="btn btn-primary" name="submit">Done</button>
        </div>      

    </form>

   <?php
        if(isset($_POST['submit']))
        {
           makeAnnouncement();
        }
    ?>

</div>

</div>
