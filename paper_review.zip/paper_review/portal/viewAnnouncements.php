
<h1 class="page-header">
  View Announcement
</h1>

<div class="col-md-5">
    
    <form method="post">
    
        <?php 
        
            $id = $_SESSION['u_id'];
    
            $query = query("SELECT * FROM reviewer where student_id = '$id'");
            confirm($query);

            while($row = fetch_array($query)){

                $query3 = query("SELECT * FROM announcement where id = '{$row['announcement_id']}'");
                confirm($query3);
                $row3 = fetch_array($query3);
                
                $s_id = $row3['subject_id'];

                $query2 = query("SELECT name FROM subject where id = '$s_id'");
                confirm($query2);

                $row2 = fetch_array($query2);

                echo "
                    <div class='card' style='width: 58rem; border:5px solid grey; border-radius:15px; text-align:center; padding:10px;margin-top:10px'>
                      <div class='card-body'>
                        <h2>{$row3['exam']}</h2>
                        <h4>{$row2['name']}</h4>

                        <a href='std_portal.php?view_std_marks={$row3['id']}&std_id={$id}' class='btn btn-primary'> View Marks </a>
                        <a href='std_portal.php?check_std_review={$row3['id']}&std_id={$id}' class='btn btn-primary'> Check Reviews </a>
                        <a href='std_portal.php?std_comments={$row3['id']}&std_id={$id}' class='btn btn-primary'> Comments </a>
                        
                      </div>
                    </div>
                    <br>
                ";
    
}
        
        ?>
        
        
    </form>


</div>

</div>
