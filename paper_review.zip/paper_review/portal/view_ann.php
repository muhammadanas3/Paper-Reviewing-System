
<h1 class="page-header">
  View Announcement
</h1>

<div class="col-md-5">
    
    <form method="post">
    
        <?php view_announcement(); ?>
        
        
    </form>


</div>

</div>
