<?php require_once("../config.php"); ?>

<?php include("header.php"); ?>


<?php 

    if(!isset($_SESSION['u_id'])){
        //session_destroy();
        //redirect("../index.php"); 
    }
    

?>

    <h3 class="text-center bg-warning"><?php display_message(); ?></h3>

        <div id="page-wrapper">

            <div class="container-fluid">

                    <?php 
                
                        if(isset($_GET['makeAnnouncement'])){

                          include("makeAnnouncement.php");  

                        }
                
                        if(isset($_GET['myAnnouncement'])){

                          include("myAnnouncement.php");  

                        }
                
                        if(isset($_GET['review'])){

                          include("review.php");  

                        }
                        if(isset($_GET['review_paper'])){

                          include("paper.php");   

                        }
                        if(isset($_GET['comment'])){

                          include("comment.php");   

                        }
                        if(isset($_GET['totalmarks'])){

                          include("totalmarks.php");   

                        }        
                        if(isset($_GET['view_ann'])){

                          include("view_ann.php");   

                        }
                        if(isset($_GET['check_review'])){

                          include("check_review.php");   

                        }
                        if(isset($_GET['update_marks'])){

                          include("update_marks.php");   

                        }
                
                
                    ?>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

<?php include("footer.php"); ?>