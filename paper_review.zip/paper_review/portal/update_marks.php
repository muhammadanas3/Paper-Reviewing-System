
<h1 class="page-header">
  Update Marks
</h1>

<div class="col-md-4">
    
    <form method="post">
    
        <?php 
            
            $std_id = $_GET['update_marks'];
            $ann_id = $_GET['ann'];
            
            $query = query("SELECT q_nos FROM announcement where id = '$ann_id'");
            confirm($query);
            $row = fetch_array($query);    
            
            $i = 1;
            echo '
                <div class="form-group">
                ';
            
            while($row['q_nos']>0){
            
                
                $query3 = query("SELECT total_marks FROM total_marks where announcement_id = '$ann_id' and q_no = {$i}");
                confirm($query3);
                $row3 = fetch_array($query3);

                
                echo"
                    <h3>Q{$i}</h3>
                    <div class = 'form-group'>
                        <input type = 'text' name='q{$i}' placeholder='Enter obtained marks' class='form-control' required>
                        Out of {$row3['total_marks']}
                    </div>
                ";
                $row['q_nos']--;
                $i++;
            }
            
            echo '
                    
                    <br>
                    <button class="btn btn-primary" name="update">Update</button>
                </div>   
            ';
            if(isset($_POST['update']))
            {
                $i = 1;
                $query4 = query("SELECT id FROM total_marks where announcement_id = '$ann_id'");
                confirm($query4);
                
                while($row4 = fetch_array($query4))
                {
                    //query("INSERT INTO obtain_marks (tot_id, student_id, obtain_marks) VALUES('{$row4['id']}', '$std_id', '{$_POST['q'.$i]}')");    
                    query("UPDATE obtain_marks SET obtain_marks = '{$_POST['q'.$i]}' WHERE tot_id = '{$row4['id']}' && student_id = '$std_id'");
                    $i++;
                }
                set_message("Marks Updated!");
                redirect("tchr_portal.php?view_ann={$ann_id}");
            }
        
        ?>
    </form>


</div>

</div>
