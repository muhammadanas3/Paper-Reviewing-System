
<h1 class="page-header">
  View Marks
</h1>

<div class="col-md-4">
    
    <form method="post">
    
        <?php 
            
            $ann_id = $_GET['view_std_marks'];
            $std_id = $_GET['std_id'];
            
            $query = query("SELECT * FROM total_marks where announcement_id = '$ann_id'");
            confirm($query);

            $i = 1;
        
            while($row = fetch_array($query))
            {
                $query2 = query("SELECT * FROM obtain_marks where tot_id = '{$row['id']}' && student_id = '$std_id'");
                confirm($query2);
                $row2 = fetch_array($query2);
                
                echo "<h4>Q{$row['q_no']}  Obtained marks == {$row2['obtain_marks']}</h4>";

            }
            
        ?>
        
    </form>


</div>

</div>
