
<h1 class="page-header">
  Make Announcement
</h1>

<div class="col-md-4">
    
    <form method="post">
    
        <div class="form-group">
            
            <select name="exam" class="form-control" required>
                <option selected>Select exam type*</option>  
                <option>Quiz</option>
                <option>Mid-1</option>
                <option>Mid-2</option>
                <option>Final</option>
            </select>
            
            <br>
            
            <select name="subject" class="form-control" required>
                <option selected>Select a subject*</option>  
                <?php
                    get_subjects();
                ?>
            </select>
            
            <br>
            
            <label>Enter number of questions</label>  
                
            <br>
            
            <input type="number" name="qno" required>
            
            <br>
            <br>
            
            
            
            <button class="btn btn-primary" name="next">Next</button>
        
<!--            //href = "tchr_portal.php?totalmarks"-->
            
            <?php
                
                if(isset($_POST['next']) && $_POST['exam'] != "Select exam type*" && $_POST['subject'] != "Select a subject*")
                {
                    $i = $_POST['qno'];
                    $exam = $_POST['exam'];
                    $sub = $_POST['subject'];
                    redirect("tchr_portal.php?totalmarks=$i&exam=$exam&subject=$sub");
                }
                    
            
            ?>
            
        
            </div>      

            
    </form>
    
</div>

</div>

