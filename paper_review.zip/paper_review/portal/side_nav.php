            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <!-- <li class="active">
                        <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li> -->
                    <li class="">
                        <a href="tchr_portal.php?makeAnnouncement"><i class=""></i> Make Announcement </a>
                    </li>
                    <li class="">
                        <a href="tchr_portal.php?myAnnouncement"><i class=""></i> My Announcements </a>
                    </li>
                    <li class="">
                        <a href="tchr_portal.php?review"><i class=""></i> Review Papers </a>
                    </li>
                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
