
<h1 class="page-header">
  Check Reviews
</h1>

<div class="col-md-4">
    
    <form method="post">
    
        <?php 
            
            $std_id = $_GET['check_review'];
            $ann_id = $_GET['ann'];
            
            $query = query("SELECT * FROM reviewer where announcement_id = '$ann_id' && student_id = '$std_id' && status = '1'");
            confirm($query);
            
            $query3 = query("SELECT distinct(reviewer_id) AS r_id FROM reviewer where announcement_id = '$ann_id' && student_id = '$std_id' && status = '1'");
            confirm($query3);
            $i = 1;
            while($row3 = fetch_array($query3))
            {
                echo "<h5>Annonymous Reviewer {$i}</h5>";
                $i++;
                
                $query2 = query("SELECT q_nos FROM announcement where id = '$ann_id'");
                confirm($query2);
                $row2 = fetch_array($query2);
                $j = 1;
                while($row2['q_nos'] > 0)
                {
                    $query = query("SELECT * FROM reviewer where announcement_id = '$ann_id' && student_id = '$std_id' && status = '1' && reviewer_id = '$row3[r_id]' && q_no = '$j'");
                    $j++;
                    confirm($query);
                    $row = fetch_array($query);
                    echo "<h4>Q{$row['q_no']}  Obtained marks == {$row['obtain_marks']}</h4>";
                    $row2['q_nos']--;
                }
                echo"<br>";
                
            }
        
//            $query = query("SELECT * FROM reviewer where announcement_id = '$ann_id' && student_id = '$std_id' && status = '1'");
//            confirm($query);
//
//            $i = 1;
//        
//            while($row = fetch_array($query))
//            {
//                echo "<h5>Annonymous Reviewer {$i}</h5>";
//                $i++;
//                $query2 = query("SELECT * FROM reviewer_pics where paper_reviewer_id = '{$row['id']}'");
//                confirm($query2);
//                while($row2 = fetch_array($query2))
//                {
//                    $query3 = query("SELECT * FROM pics where id = '{$row2['pic_id']}'");
//                    confirm($query3);
//                    $row3 = fetch_array($query3);
//                    
//                    echo "<h4>Q{$row3['question_no']}  Obtained marks == {$row2['obtain_marks']}</h4>";
//                    
//                }
//
//            }
            
        ?>
        
    </form>


</div>

</div>
