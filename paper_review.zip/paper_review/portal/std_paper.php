
<h1 class="page-header">
  Review Panel
</h1>



<div class="col-md-4">
    <form method = 'post'>
       <?php
          get_std_paper($_GET['std_review_paper']);    
        ?>
    </form>
</div>

</div>

