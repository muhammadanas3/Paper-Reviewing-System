<?php 
    require_once("config.php");
    
    if(isset($_SESSION['u_id']))
        //redirect("portal.php");

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	    
    
          <h3 class="text-center"><?php display_message(); ?></h3>
    
	<div class="limiter">
		<div class="container-login100">
		
            
            <div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="post">
					<span class="login100-form-title">
						Log In
					</span>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter id">
						<input class="input100" type="text" name="id" placeholder="Id" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Please enter password">
						<input class="input100" type="password" name="pass" placeholder="Password" required>
						<span class="focus-input100"></span>
					</div>
                    
                    <br>

                    <center>
                        <label class="radio-inline">
                            <input type="radio" name="optradio" value="1" checked> Student
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="optradio" value="2"> Teacher
                        </label>
                    </center>
                    
                    <br>
                        
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="login">
							Log in
						</button>
					</div>
                    <br>
					
				</form>
                
                <?php
                    if(isset($_POST['login']) && $_POST['optradio'] == "1")
                    {
                        student_login();
                    }
                    else if(isset($_POST['login']) && $_POST['optradio'] == "2")
                    {
                        teacher_login();
                    }
                ?>
                
                 
			</div>
            
		</div>
        
	</div>
              
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>