<?php

//helper functions

    function set_message($msg){
        if(!empty($msg)){
            $_SESSION['message'] = $msg;
        }
        else{
            $msg = "";
        }
    }

    function display_message(){
        if(isset($_SESSION['message'])){
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
    }


    function redirect($location){
        header("Location: $location");
    }
    function query($sql){
        global $connection;
        return mysqli_query($connection, $sql);
    }
    function confirm($result){
        if(!$result){
            die("QUERY FAILED" . mysqli_error($connection));
        }
    }
    function escape_string($string){
        global $connection;
        return mysqli_real_escape_string($connection, $string);
    }
    function fetch_array($result){
        return mysqli_fetch_array($result);
    }



/*****************FRONT END FUNCTIONS*********************/


function student_login()
{
    $id = escape_string($_POST['id']);
    $pass = escape_string($_POST['pass']);
    
    $query = query("SELECT * FROM student WHERE id = '{$id}' AND password = '{$pass}'");
    confirm($query); 
    
    if(mysqli_num_rows($query) == 0)
    {
        set_message("Invalid Email or Password");
        redirect("index.php");
    }
    else
    {    
        $row = fetch_array($query);
        $_SESSION['name'] = $row['name'];
        $_SESSION['u_id'] = $row['id'];
        $_SESSION['type'] = "s";
        header("Location: portal/std_portal.php");
    
    }
}

function teacher_login()
{
    $id = escape_string($_POST['id']);
    $pass = escape_string($_POST['pass']);
    
    $query = query("SELECT * FROM teacher WHERE id = '{$id}' AND password = '{$pass}'");
    confirm($query); 
    
    if(mysqli_num_rows($query) == 0)
    {
        set_message("Invalid Email or Password");
        redirect("index.php");
    }
    else
    {    
        $row = fetch_array($query);
        $_SESSION['name'] = $row['name'];
        $_SESSION['u_id'] = $row['id'];
        $_SESSION['type'] = "t";
        header("Location: portal/tchr_portal.php");
    
    }
}


function get_subjects(){

    $query = query("SELECT * FROM subject");
    confirm($query);

    while($row = fetch_array($query)){
        echo "<option value = " . $row['id'] . ">" . $row['name'] . "</option>";
        
    }
}


function makeAnnouncement(){
    
    $id = $_SESSION['u_id'];
    $sub_id = $_GET['subject'];
    $exam = $_GET['exam'];
    $qno = $_GET['totalmarks'];
    
    query("INSERT INTO announcement (teacher_id, subject_id, exam, q_nos) VALUES('$id', '$sub_id', '$exam', '$qno')");
    
    $aId_query = query("SELECT max(id) AS aId FROM announcement");
    $row = fetch_array($aId_query);
    $aId = $row['aId'];
    $i = 1;
    
    while($qno > 0)
    {
        query("INSERT INTO total_marks (announcement_id, q_no, total_marks) VALUES('$aId', '$i', '{$_POST['q'.$i]}')");
        $qno--;
        $i++;
    }
    
    set_message("Announcement made!");
    redirect("tchr_portal.php?makeAnnouncement");
    
}


function get_announcements(){

    $id = $_SESSION['u_id'];
    
$query = query("SELECT * FROM announcement where teacher_id = '$id'");
confirm($query);
    
while($row = fetch_array($query)){
    
    $s_id = $row['subject_id'];
    
    $query2 = query("SELECT name FROM subject where id = '$s_id'");
    confirm($query2);
    
    $row2 = fetch_array($query2);
    
$ann = <<<DELIMETER

<div class="card" style="width: 58rem; border:5px solid grey; border-radius:15px; text-align:center; padding:10px;margin-top:10px">
  <div class="card-body">
    <h2>{$row['exam']}</h2>
    <h4>{$row2['name']}</h4>
    
    <a href="tchr_portal.php?view_ann={$row['id']}" class="btn btn-primary"> View </a>
    
  </div>
</div>
    <br>

DELIMETER;

echo $ann;        
    
}
    //  $a = new SimpleXMLElement('<a href="#{$row['id']}">aaaa</a>');
    // echo $a['href'];
    
}


function view_announcement(){
    
    $anId = $_GET['view_ann'];
   
    $query = query("SELECT * FROM announcement where id = '$anId'");
    confirm($query);
    $row = fetch_array($query);
    
    $query2 = query("SELECT name FROM subject where id = '{$row['subject_id']}'");
    confirm($query2);
    $row2 = fetch_array($query2);
    
    echo "<h3>{$row2['name']} -- {$row['exam']}</h3><hr>";
    
    $query3 = query("SELECT distinct(student_id) FROM reviewer where announcement_id = '$anId'");
    confirm($query3);
    
    while($row3 = fetch_array($query3))
    {
        echo "
            <div class='form-group'>
                <h4>{$row3['student_id']}</h4>   
                <a href='tchr_portal.php?check_review={$row3['student_id']}&ann={$anId}' class='btn btn-primary'>Check Reviews</a>
                <a href='tchr_portal.php?update_marks={$row3['student_id']}&ann={$anId}' class='btn btn-primary'>Update Marks</a>
                <a href='tchr_portal.php?comment={$row3['student_id']}&ann={$anId}' class='btn btn-primary'> Comments </a>
            </div>   
            <br>
        ";
        
    }
}


function get_review(){

    $id = $_SESSION['u_id'];
    
$query = query("SELECT distinct(announcement_id) FROM reviewer where reviewer_id = '$id' && status = '0'");
confirm($query);
    
while($row = fetch_array($query)){
    
    $a_id = $row['announcement_id'];
    
  //  echo $a_id;
  
    $query4 = query("SELECT subject_id FROM announcement WHERE id = '$a_id'");
    confirm($query4);
    
    $row4 = fetch_array($query4);
    $sub_id = $row4['subject_id'];
    
    $query2 = query("SELECT name FROM subject where id = '$sub_id'");
    confirm($query2);
    
    $query3 = query("SELECT exam FROM announcement WHERE id = '$a_id'");
    confirm($query3);
    
    $row2 = fetch_array($query2);
    $row3 = fetch_array($query3);
    
    
$ann = <<<DELIMETER

<div class="card" style="width: 58rem; border:5px solid grey; border-radius:15px; text-align:center; padding:10px;margin-top:10px">
  <div class="card-body">
    
    <h2>{$row3['exam']}</h2>
    <h4>{$row2['name']}</h4>

    <a href="tchr_portal.php?review_paper={$a_id}" class="btn btn-primary"> Review </a>
    
  </div>
</div>
    <br>

DELIMETER;

echo $ann;        
    
}
    //  $a = new SimpleXMLElement('<a href="#{$row['id']}">aaaa</a>');
    // echo $a['href'];
    
}

function get_std_review(){

    $id = $_SESSION['u_id'];
$query = query("SELECT distinct(announcement_id) FROM reviewer where reviewer_id = '$id' && status = '0'");
confirm($query);
    
while($row = fetch_array($query)){
    
    $a_id = $row['announcement_id'];
    
  //  echo $a_id;
  
    $query4 = query("SELECT subject_id FROM announcement WHERE id = '$a_id'");
    confirm($query4);
    
    $row4 = fetch_array($query4);
    $sub_id = $row4['subject_id'];
    
    $query2 = query("SELECT name FROM subject where id = '$sub_id'");
    confirm($query2);
    
    $query3 = query("SELECT exam FROM announcement WHERE id = '$a_id'");
    confirm($query3);
    
    $row2 = fetch_array($query2);
    $row3 = fetch_array($query3);
    
    
$ann = <<<DELIMETER

<div class="card" style="width: 58rem; border:5px solid grey; border-radius:15px; text-align:center; padding:10px;margin-top:10px">
  <div class="card-body">
    
    <h2>{$row3['exam']}</h2>
    <h4>{$row2['name']}</h4>

    <a href="std_portal.php?std_review_paper={$a_id}" class="btn btn-primary"> Review </a>
    
  </div>
</div>
    <br>

DELIMETER;

echo $ann;        
    
}
    //  $a = new SimpleXMLElement('<a href="#{$row['id']}">aaaa</a>');
    // echo $a['href'];
    
}


function get_paper($a_id){
    
    
//    echo "<a href='tchr_portal.php?review_paper=1' class='btn btn-primary'> Back to Pics </a>";
    
    
    $queryc = query("SELECT * FROM reviewer where announcement_id = '$a_id' && reviewer_id = {$_SESSION['u_id']}");
    confirm($queryc);
//    $rowc = fetch_array($queryc);
    
//    $query = query("SELECT pic_id FROM reviewer_pics where paper_reviewer_id = '{$rowc['id']}'");
//    confirm($query);
    
    while($rowc = fetch_array($queryc))
    {
        //$p_id = $row['pic_id'];
    
//        $query2 = query("SELECT * FROM pics where id = '$p_id'");
//        confirm($query2);
//        $row2 = fetch_array($query2);
//
//        $p = $row2['path'];

        $query3 = query("SELECT total_marks FROM total_marks where announcement_id = '$a_id' and q_no = {$rowc['q_no']}");
        confirm($query3);
        $row3 = fetch_array($query3);
        
        echo "
            <div>
                <h2>Q{$rowc['q_no']}</h2>
                <img src='{$rowc['pic_path']}' alt='{$rowc['pic_path']}' height='800px' width='600px'>
                    <br>
                    <br>
                    <div class = 'form-group'>
                        <input type = 'text' name='obt{$rowc['q_no']}' placeholder='Enter obtained marks' class='form-control' required>
                        Out of {$row3['total_marks']}
                    </div>
            </div>  
          
        ";
    }
    
    echo '
        <button class="btn btn-primary" type="submit" name="submitn">Submit Review</button>   
        ';
    if(isset($_POST['submitn']))
    {
//        $querycn = query("SELECT * FROM reviewer where paper_reviewer_id = '{$rowc['id']}'");
//        confirm($querycn);
        $queryc = query("SELECT * FROM reviewer where announcement_id = '$a_id' && reviewer_id = '{$_SESSION['u_id']}'");
    confirm($queryc);
        while($rown = fetch_array($queryc))
        {
            $pId = (int)$rown['id'];
            
//            $query2n = query("SELECT * FROM pics where id = '{$rown['pic_id']}'");
//            confirm($query2n);
//            $row2n = fetch_array($query2n);
            
            $qn = $rown['q_no'];
            $qn = (int)$_POST['obt'.$qn];
            
            //echo $qn;
            
            query("UPDATE reviewer SET obtain_marks = '$qn' WHERE id = '$pId'");
            
            query("UPDATE reviewer SET status = '1' WHERE id = '$pId'");   
//            
            set_message("Review Submitted!");
            redirect("tchr_portal.php?review");
    
        }
            
    }
    
    
}


function get_std_paper($a_id){
    
    
//    echo "<a href='tchr_portal.php?review_paper=1' class='btn btn-primary'> Back to Pics </a>";
    $queryc = query("SELECT * FROM reviewer where announcement_id = '$a_id' && reviewer_id = '{$_SESSION['u_id']}'");
    confirm($queryc);
//    $rowc = fetch_array($queryc);
//    
//    $query = query("SELECT pic_id FROM reviewer_pics where paper_reviewer_id = '{$rowc['id']}'");
//    confirm($query);
    
    while($rowc = fetch_array($queryc))
    {
//        $p_id = $rowc['pic_id'];
//    
//        $query2 = query("SELECT * FROM pics where id = '$p_id'");
//        confirm($query2);
//        $row2 = fetch_array($query2);

        $p = $rowc['pic_path'];

        $query3 = query("SELECT total_marks FROM total_marks where announcement_id = '$a_id' and q_no = {$rowc['q_no']}");
        confirm($query3);
        $row3 = fetch_array($query3);
        
        echo "
            <div>
                <h2>Q{$rowc['q_no']}</h2>
                <img src='{$rowc['pic_path']}' alt = '{$rowc['pic_path']}' height='800px' width='600px'>
                    <br>
                    <br>
                    <div class = 'form-group'>
                        <input type = 'text' name='obt{$rowc['q_no']}' placeholder='Enter obtained marks' class='form-control' required>
                        Out of {$row3['total_marks']}
                    </div>
            </div>  
          
        ";
    }
    
    echo '
        <button class="btn btn-primary" name="submitn">Submit Review</button>   
        ';
    if(isset($_POST['submitn']))
    {
//        $querycn = query("SELECT * FROM reviewer where paper_reviewer_id = '{$rowc['id']}'");
//        confirm($querycn);
        $queryc = query("SELECT * FROM reviewer where announcement_id = '$a_id' && reviewer_id = '{$_SESSION['u_id']}'");
    confirm($queryc);
        while($rown = fetch_array($queryc))
        {
            $pId = (int)$rown['id'];
            
//            $query2n = query("SELECT * FROM pics where id = '{$rown['pic_id']}'");
//            confirm($query2n);
//            $row2n = fetch_array($query2n);
            
            $qn = $rown['q_no'];
            $qn = (int)$_POST['obt'.$qn];
            
            //echo $qn;
            
            query("UPDATE reviewer SET obtain_marks = '$qn' WHERE id = '$pId'");
            
            query("UPDATE reviewer SET status = '1' WHERE id = '$pId'");   
//            
            set_message("Review Submitted!");
            redirect("std_portal.php?stdreview");
    
        }
            
    }
    
    
}


function get_comments(){

    $std_id = $_GET['comment'];
    $a_id = $_GET['ann'];
    $id = $_SESSION['u_id'];
    
$query = query("SELECT * FROM comments where student_id = '$std_id' AND announcement_id = '$a_id'");
confirm($query);
    
while($row = fetch_array($query)){
    
    if($row['type'] == 't')
    {
$comm = <<<DELIMETER
<div class="row">
    
<div class="col-md-4">
    <div class="card" style="width:auto; border:3px solid grey; border-radius:15px; padding-left:10px;">
      <div class="card-body">
        <h4>{$row['comment']}</h3>
        <h6>Teacher --- {$row['datetime']}</h6>
      </div>
    </div>
    </div>
</div>
<br>

DELIMETER;
    }
    
    else if($row['type'] == 's')
    {
$comm = <<<DELIMETER
<div class="row">
    
 <div class="col-md-4"> </div>
    <div class="col-md-4"> </div>
    
    <div class="col-md-4">
<div class="card" style="width:auto; border:3px solid grey; border-radius:15px; padding-left:10px;">
  <div class="card-body">
    <h4>{$row['comment']}</h3>
    <h6>{$std_id} --- {$row['datetime']}</h6>
  </div>
</div>
    
</div>
</div>
<br>
DELIMETER;
    }
    
    
echo $comm;        
    
    
}
    
}

function get_std_comments(){

    $std_id = $_GET['std_id'];
    $a_id = $_GET['std_comments'];
    $id = $_SESSION['u_id'];
    
$query = query("SELECT * FROM comments where student_id = '$std_id' AND announcement_id = '$a_id'");
confirm($query);
    
while($row = fetch_array($query)){
    
    if($row['type'] == 't')
    {
$comm = <<<DELIMETER
<div class="row">
    
<div class="col-md-4">
    <div class="card" style="width:auto; border:3px solid grey; border-radius:15px; padding-left:10px;">
      <div class="card-body">
        <h4>{$row['comment']}</h3>
        <h6>Teacher --- {$row['datetime']}</h6>
      </div>
    </div>
    </div>
</div>
<br>

DELIMETER;
    }
    
    else if($row['type'] == 's')
    {
$comm = <<<DELIMETER
<div class="row">
    
 <div class="col-md-4"> </div>
    <div class="col-md-4"> </div>
    
    <div class="col-md-4">
<div class="card" style="width:auto; border:3px solid grey; border-radius:15px; padding-left:10px;">
  <div class="card-body">
    <h4>{$row['comment']}</h3>
    <h6>{$std_id} --- {$row['datetime']}</h6>
  </div>
</div>
        
</div>
</div>
<br>
DELIMETER;
    }
    
    
echo $comm;        
    
    
}
    
}

function addRComment($cmnt, $a_id){

    //$r_id = $_SESSION['u_id'];
    $std_id = $_GET['comment'];
    
    $now = (new DateTime('now'))->format('Y-m-d H:i:s');
//    echo $std_id;
    //query("INSERT INTO comments (announcement_id, student_id, comment, datetime, type) VALUES('$a_id', '$std_id', '$cmnt', $now, 't')");
    query("INSERT INTO comments (announcement_id, student_id, comment, type) VALUES('$a_id', '$std_id', '$cmnt', 't')");

}


function addSComment($cmnt, $a_id){

    //$r_id = $_SESSION['u_id'];
    $std_id = $_GET['std_id'];
    
    $now = (new DateTime('now'))->format('Y-m-d H:i:s');
//    echo $std_id;
    //query("INSERT INTO comments (announcement_id, student_id, comment, datetime, type) VALUES('$a_id', '$std_id', '$cmnt', $now, 't')");
    query("INSERT INTO comments (announcement_id, student_id, comment, type) VALUES('$a_id', '$std_id', '$cmnt', 's')");

}

function std_signup()
{
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sem = $_POST['semester'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    
    query("INSERT INTO student VALUES('$id', '$name','$sem','$email', '$pass', '0')");

    $_SESSION['u_id'] = $id;
    set_message("Student Signed up Successfully");
    redirect("portal/std_portal.php");
    
}
















function admin_login()
{
    $email = escape_string($_POST['email']);
    $pass = escape_string($_POST['pass']);
    
    $query = query("SELECT * FROM admin WHERE email = '{$email}' AND password = '{$pass}'");
    //echo "SELECT * FROM user WHERE email = '{$email}' AND password = '{$pass}'";
    confirm($query); 
    
    if(mysqli_num_rows($query) == 0)
    {
        set_message("Invalid Email or Password");
        redirect("admin_login.php");
        //echo "adfa";
    }
    else
    {    
        $row = fetch_array($query);

        $_SESSION['name'] = $row['name'];
        $_SESSION['u_id'] = $row['id'];
        
        //echo $_SESSION['name'];
        
        redirect("admin/index.php?viewlog");
        
        
    }
}


function get_category(){

$query = query("SELECT id, name FROM category");
confirm($query);

    $i = 0;
    
while($row = fetch_array($query)){
    
$item = <<<DELIMETER
<li class="nav-item">
    <a href="portal.php?catid={$row['id']}" class="nav-link">{$row['name']}</a>    
</li>

DELIMETER;

echo $item;        
    
}
    //  $a = new SimpleXMLElement('<a href="#{$row['id']}">aaaa</a>');
    // echo $a['href'];
    
}


function view_log()
        {
        	$query = query("SELECT * FROM userlog");
            confirm($query);
            

            while($row = fetch_array($query))
            {

            	$query1 = query("SELECT name FROM user where id = '{$row['user_id']}'");
            	confirm($query1);
				$row1 = fetch_array($query1);

$log = <<<DELIMETER

<tr>
  <td>{$row['id']}</td>
  <td>{$row['user_id']}</td>
  <td>{$row1['name']}</td>
  <td>{$row['login_datetime']}</td>
  <td>{$row['logout_datetime']}</td>
</tr>

DELIMETER;

echo $log;

            }
        }


function view_stock()
        {
        	$query = query("SELECT * FROM stock");
            confirm($query);
            

            while($row = fetch_array($query))
            {

            	$query1 = query("SELECT name FROM item where id = '{$row['item_id']}'");
            	confirm($query1);
				$row1 = fetch_array($query1);

$item = <<<DELIMETER

<tr>
  <td>{$row['id']}</td>
  <td>{$row['item_id']}</td>
  <td>{$row1['name']}</td>
  <td>{$row['quantity']}</td>
  <td>{$row['arrival_date']}</td>
</tr>

DELIMETER;

echo $item;

            }
        }



function view_user()
        {
        	$query = query("SELECT * FROM user");
            confirm($query);
            

            while($row = fetch_array($query))
            {

$user = <<<DELIMETER

<tr>
  <td>{$row['id']}</td>
  <td>{$row['name']}</td>
  <td>{$row['address']}</td>
  <td>{$row['phone']}</td>
  <td>{$row['email']}</td>
  <td>{$row['password']}</td>
</tr>

DELIMETER;

echo $user;

            }
        }


function addUser()
        {
        	$uName = $_POST['userName'];
            $addr = $_POST['userAddress'];
            $phone = $_POST['userPhone'];
            $email = $_POST['userEmail'];
            $pass = $_POST['userPassword'];

        	query("INSERT INTO user(name, address, phone, email, password) VALUES('$uName', '$addr', '$phone', '$email', '$pass')");

        	set_message("User Added!");
            redirect("index.php?adduser");

        }

function get_user(){

    $query = query("SELECT * FROM user");
    confirm($query);

    while($row = fetch_array($query)){
        echo "<option value = " . $row['id'] . ">" . $row['name'] . "</option>";
        
    }
}


function delUser()
{
        query("DELETE FROM user WHERE id = " .escape_string($_POST['user_name']). " ");
        set_message("User Deleted!");
        redirect("index.php?deleteuser");  
}



function addCat()
        {
        	$catName = $_POST['catName'];

        	query("INSERT INTO category(name) VALUES('$catName')");

        	set_message("Category Added!");
            redirect("index.php?addcategory");

        }

function get_cat(){

    $query = query("SELECT * FROM category");
    confirm($query);

    while($row = fetch_array($query)){
        echo "<option value = " . $row['id'] . ">" . $row['name'] . "</option>";
        
    }
}

function delCat()
{
        query("DELETE FROM category WHERE id = " .escape_string($_POST['cat_name']). " ");
        set_message("Category Deleted!");
        redirect("index.php?deletecategory");  
}




function delitem()
{
        query("DELETE FROM item WHERE id = " .escape_string($_POST['item_name']). " ");
        set_message("Item Deleted!");
        redirect("index.php?deleteitem");  
}


function get_cat_name($id)
{
    $query = query("SELECT name FROM category where id = '$id'");
    confirm($query);

    $row = fetch_array($query);
    echo $row['name'];
}


function get_item(){

    $query = query("SELECT * FROM item");
    confirm($query);

    while($row = fetch_array($query)){
        echo "<option value = " . $row['id'] . ">" . $row['name'] . "</option>";
        
    }
}

function addItem()
        {
                    
            $itemName = $_POST['itemName'];
            
        	$catId = $_POST['cat_name'];
            $itemPrice = $_POST['itemPrice'];
    
            if($_POST['itemQuantity'] > 0){
                $itemQuantity = $_POST['itemQuantity'];
            }
            else{
                set_message("Units must be greater than 0");
                redirect("index.php?additem"); 
            }
//    
//            echo $itemName." ";
//            echo $catId." ";
//            echo $itemPrice." ";
//            echo $itemQuantity." ";
//            echo $_FILES['file']['name']." ";
    
            $file = $_FILES['file'];

            $fileName = $_FILES['file']['name'];
            $fileTmpName = $_FILES['file']['tmp_name'];
            $fileSize = $_FILES['file']['size'];
            $fileError = $_FILES['file']['error'];
            $fileType = $_FILES['file']['type'];
            $fileDestination = "";
            $fileExt = explode('.', $fileName);
            $fileActualExt = strtolower(end($fileExt));

            $allowed = array('jpg', 'jpeg', 'png');

            if(in_array($fileActualExt, $allowed)){

                if($fileError === 0){

                    if($fileSize < 1000000){

                        $fileNameNew = uniqid('', true).".".$fileActualExt;
                        $fileDestination = 'item_images/'.$fileNameNew;

                        $a = move_uploaded_file($fileTmpName, "../".$fileDestination);
                        
                        if($a)
                        {
                            $insert_item = query("INSERT INTO item(name, category_id, price, image) VALUES('$itemName','$catId','$itemPrice','$fileDestination')");

                            $pId_query = query("SELECT max(id) AS newId FROM item");
                            confirm($pId_query);
                            $new_product_id = fetch_array($pId_query);

                            $now = (new DateTime('now'))->format('Y-m-d H:i:s');

                            query("INSERT INTO stock(item_id, quantity, arrival_date) VALUES('{$new_product_id['newId']}','$itemQuantity','$now')");

                            set_message("Item Added Successfully");

                            redirect("index.php?additem"); 
    
                        }
    
                        
                    }else{
                        set_message("File size is too big.");
                    }

                }else{
                    set_message("There was an error uploading your file.");
                }

            }else{
                set_message("File type not allowed.");
            }

        }

function get_items($catid){

$query = query("SELECT * FROM item where category_id='{$catid}'");
confirm($query);
$i=0;
echo '<div class ="container">';
while($row = fetch_array($query)){
    
    $query2 = query("SELECT * FROM stock where item_id='{$row['id']}'");
    confirm($query2);
    $row2 = fetch_array($query2);

if($i%2 == 0) echo '<div class="row align-items-center">';    
$item = <<<DELIMETER

    <div class="col-md-4">
        <div class="product-image-wrapper">
            <div class="single-products">  
                <div class="productinfo text-center">
                    <img src="{$row['image']}" alt="{$row['name']}">
                    <h2>{$row['name']}</h2>
                    <h4>Qunatity: {$row2['quantity']}</h4>
                    <h4>Rs {$row['price']}</h4>
                  
                    <button class='btn btn-success' name="addbtn" onclick="addQuantity('{$row['name']}')"><span class='glyphicon glyphicon-plus'></span></button>
                    <button class='btn btn-danger' onclick="removeQuantity('{$row['name']}')"><span class='glyphicon glyphicon-minus'></span></button>
                </div>
                
                
            </div>
        </div>
    </div>

DELIMETER;
if($i%2 == 0) echo '</div>';
$i++;
echo $item;
}   
    echo '</div>';
}


?>

<script>
    function addQuantity(foo){
        if(document.getElementById(foo) != null){
            document.getElementById(foo).children[1].innerHTML = parseInt(document.getElementById(foo).children[1].innerHTML) + 1;
        }else{
            let tr = document.createElement("tr");
            let name = document.createElement("td");
            let quantity = document.createElement("td");
            tr.id = foo;
            name.innerHTML = foo;
            quantity.innerHTML = "1";
            tr.appendChild(name);
            tr.appendChild(quantity);
            let parent = document.getElementById("tb");
            parent.appendChild(tr);
        }
        
    }
    function removeQuantity(foo){
        if(document.getElementById(foo) != null){
            document.getElementById(foo).children[1].innerHTML = parseInt(document.getElementById(foo).children[1].innerHTML)-1;
        }
    }

</script>